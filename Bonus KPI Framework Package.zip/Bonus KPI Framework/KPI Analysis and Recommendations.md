# KPI analysis and recommended proposal

This package follows the original PowerPoint design and introduces the bonus framework generally. It does not lead with a cost-reduction or rollout narrative. Source workbooks and previous prototypes are unchanged.

## Findings from the supplied workbook

- 84 rules: 42 Tenured and 42 Untenured. Both tenure configurations are identical.
- 181 identified agents: 135 Tenured and 46 Untenured. Of the 46 Untenured records, 19 belong to unconfigured ACM FR; the configured Untenured cohort is 27.
- All 135 positive AHT / Productivity pairs satisfy AHT × Productivity = 3,300 within 0.001. The two other numeric pairs are zeros. This is a derived speed index in this dataset, not an independent output measure.
- The seven-productivity target implies AHT ≤471.43 seconds under that identity. It is inconsistent with the separate Ford GER AHT target of 1,000 seconds.
- PCS score and Extra PCS both use the same score. At 4.3, normal PCS earns 20 points and Extra PCS earns 20 more; maximum combined awards reach 50 points. Participation adds 15 more survey-linked points.
- PCS participation is nonblank raw-Q1 eligible inbound legs / PCSStatus-qualified inbound legs. It is not survey count / all calls. Opportunity and response behavior have not been established as fully agent-controlled.
- All VOC detractor counts are zero. The supplied data cannot test penalty impact or validate a new malus.
- Configured Untenured evidence is sparse: 5 positive AHT values, 11 numeric QM values and 25 zero PCS scores among 27 agents. WFMHub permits scores 1–5; zero scores need evidence review. Do not interpret missing / invalid evidence as measured failure.

## Proposed paid KPI mix

Quality 30%, PCS score 25%, AHT 20%, on-shift adherence 15%, absence 10%. Common weights across tenure groups; total 100%. Remove the derived Productivity award and the separate Extra PCS award at introduction. Monitor participation. FCR is a future option only after linked resolution and repeat-contact evidence exists.

Tenured (working rule: at least three completed months): QM 90% / 85%; PCS 4.3 / 4.1; AHT baseline / 110% of baseline; on-shift adherence 95% / 90%; absence 3% / 5%.

Untenured (working rule: under three completed months): QM 90% / 80%; PCS 4.3 / 4.0; AHT 125% / 140% of baseline; on-shift adherence 95% / 90%; absence 3% / 5%.

The first threshold earns the full KPI weight. The second earns 75% of the component. Tiers do not stack. Below the partial threshold earns zero only when valid evidence exists. Missing / insufficient evidence is REVIEW and does not silently reweight other KPIs. Proposed base cap 100%. Client quality minima and critical-error policies take precedence. An efficiency award requires the tenure-specific partial QM threshold to be satisfied. No original formula was altered.

These numeric targets, ramp allowances, weights and sample floors are recommended starting points for testing, not externally established best practices or statistically optimized targets. The file contains one period and insufficient Untenured evidence to establish an optimum. AHT baselines are taken from the original six-population matrix. ACM FR requires an approved baseline.

Candidate evidence floors: 20 valid PCS answers and 5 approved QA evaluations per agent/month. These are proposed testing values, not statistical guarantees. Validate feasibility by workload and volume. The workbook does not contain these counts, on-shift adherence or hire dates. A complete proposed payout simulation is therefore not claimed.

On-shift adherence is a proposed distinct behavior metric: time matching approved activity / status while present, divided by eligible attended scheduled time. Exclude approved exceptions and time already counted as absence. Validate mapping and tolerance before use. Absence uses finalized, countable absence and approved exclusions; avoid applying the same absence deduction again through proration. Keep employment-period proration distinct.

The three-month cutoff was supplied by the user; the workbook contains group labels, not a calendar-month formula or join dates to verify classification. Current dashboard results use the supplied group labels. The original filename says September, but its records and period selector use August.

## Sources

- Supplied Bonus Management workbook and Bonus Dashboard PowerPoint: exact configurations, outcomes and empirical overlap.
- [WFMHub metric catalog](https://github.com/44rive/WFMHub-Portable/blob/main/config/default_metrics.toml): AHT and PCS definitions.
- [WFMHub rules](https://github.com/44rive/WFMHub-Portable/blob/main/config/default_rules.toml): valid PCS scores 1–5.
- [NiCE Suite Metrics](https://help.nice-incontact.com/Content/metrics/suitemetrics.htm): context for handling-time and performance metrics.
- [Qualtrics Data & Analysis](https://www.qualtrics.com/support/survey-platform/data-and-analysis-module/data-and-analysis-overview/): sample-size and analysis context.

External references support measurement principles; they do not approve or establish the numerical targets in this proposal.

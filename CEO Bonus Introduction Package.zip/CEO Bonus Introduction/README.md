# CEO bonus introduction

The revised package explains the first introduction of performance-based bonuses after a new site has been paying full launch bonuses. The recommendation is a proposed shadow cycle, with full bonuses maintained during rehearsal, followed by a prospective activation decision. No start month or policy approval is assumed.

## Present

Open `Bonus Introduction - CEO Decision Brief.pptx`. Slides 1–8 tell the executive story; slides 9–11 are dashboard and method appendices. All slide text, shapes and charts are editable PowerPoint objects. Speaker notes are embedded and also supplied in `Presenter Notes.txt`. The PDF and PNGs are layout previews rendered outside PowerPoint; PowerPoint rendering should be checked before presenting.

## Power BI

The `Power BI Project` folder contains a redesigned two-page report with native cards, slicers and charts over a frozen Excel snapshot. Open `Bonus CEO.pbip` in current Power BI Desktop on Windows, enable project / enhanced report support if prompted, and initialize the embedded snapshot once with Refresh if it is not loaded. This has no Excel/CSV connection and always returns the same data. Save as PBIX after checking layout and filters. Desktop is unavailable in this workspace, so native rendering and DAX execution remain to be checked there. The dashboard PDF is a design preview, not a screenshot from Power BI.

## Financial basis

August 2026: 181 identified agents, including 162 with configured targets and 19 ACM FR agents without KPI configuration. All 162 comparable agents have a 2,000 MAD reference amount and full proration. Full-reference scenario: 324,000 MAD. Saved simulated payout: 169,500 MAD. Modelled difference: 154,500 MAD (47.7%). Actual payroll payments were not supplied. These numbers are neither confirmed savings nor payroll instructions.

Impact for the same 162 agents: 7 zero payout, 147 partial reference, 8 full reference or above. KPI reach is the share earning any award, including a lower tier. Targets and all eight policy choices remain under validation. The selected achievement cap is 130%.

The workbook filename says September, but the identified rows and dashboard use August. Two incomplete rows without Agent IDs are excluded from headcount. Three values saved just below 80% due to floating-point precision are normalized to ten decimals for comparisons only: 34 agents are at 80%+, consistent with the distribution bands. No payout amount was recalculated.

Source files and the first prototype remain unchanged. This is a local artifact containing employee data; nothing was published or committed to a repository. The CSV exporter and refresh backend remain deferred until management accepts the prototype.

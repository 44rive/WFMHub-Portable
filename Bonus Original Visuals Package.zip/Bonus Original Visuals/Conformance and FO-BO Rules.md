# Conformance, shift timing, absence and hybrid FO/BO work

The user confirmed that planning contains shift start and shift end, not FO/BO activity blocks. This package preserves the original PowerPoint's actual native objects and styles; new explanatory slides reuse those objects. Original chart XML, chart workbooks, masters and themes are retained verbatim. Only necessary labels and corrected headcounts / the 80% chip changed on the original two pages. The original sources are unchanged.

## Conformance versus the site's problem

Conformance = recognized actual working minutes / comparable scheduled working minutes × 100. The recognized activities must match the denominator: approved FO and BO are work for a whole-shift measure. An on-queue-only vendor measure can omit BO and is therefore not a whole-shift attendance measure. Break/meal inclusion must be consistent on both sides. First login / last logout are not sufficient evidence of all working minutes.

Someone scheduled 09:00–17:00 who works 09:30–17:30 can have 100% conformance. They are still 30 minutes late. Work after the approved shift does not cancel that timing breach. Use the effective approved schedule if the shift was changed. With only shift start/end planning, measure boundary timing; do not claim activity adherence or break timing compliance.

## Proposed bonus formula with no duplicated absence penalty

Define eligible planned working intervals after approved exclusions. P is their total minutes. A is the union of finalized countable absence intervals clipped to those planned intervals. L is the union of unexcused late-start / early-departure intervals within the plan, after removing A and approved exceptions. These are interval calculations, not independent counters added together.

Absence rate = 100 × A / P.
Shift timing compliance = 100 × (1 − L / (P − A)).

Preserve raw final absence for source / payroll reconciliation. The adjusted timing formula is a separate proposed bonus measure, not a native WFMHub conformance / adherence metric. If late or early minutes already appear in finalized countable absence, charge them once to absence and remove them from timing. If they do not, treat unexcused boundary minutes only as timing loss. Missing status or Activities evidence remains REVIEW, not assumed absence or a measured zero. If P=0, the absence rate is undefined. If P−A=0, shift timing is not eligible / review; never mark it 100% or automatically redistribute that weight. Settle that eligibility rule before paying the proposed scorecard.

Example: P=480, A=60, L=30. Absence=12.50%. Timing denominator=420; timing compliance=(1−30/420)×100=92.86%. The sixty absence minutes do not also reduce timing. Monthly results use ratios of summed minutes, not averages of daily rates.

This boundary metric does not diagnose excess break duration or internal unauthorized gaps by itself. Keep those operational controls visible and validate categories, allowances and accountability before adding them to a paid formula. WFMHub considers a later return an internal gap, not permanent early departure. Early departure is finalized only on completed shifts. Normal breaks and meals are not attendance gaps. Avoid repeating the absence penalty again through bonus proration; keep employment-period proration distinct.

## Hybrid FO / BO treatment

Count authorized, mapped BO as work. Do not mark an agent absent because they are off the FO queue. Availability, calls, BO, approved meetings / training, normal breaks, unexplained logout and unknown evidence need separate governed categories. An arbitrary BO AUX code alone is not proof of an approved assignment. A TL instruction or authorized assignment should record agent, activity, start, end and approval / instruction reference.

For agents doing both, calculate FO AHT from FO handling seconds / FO handled legs. Calculate PCS from eligible FO surveys only. Do not divide FO calls by full-shift hours containing BO. QA needs rubrics / evidence for both work types. Whole-shift timing and absence are scored once per agent, not once for FO and again for BO.

With no planned FO/BO blocks, it is impossible to prove that an agent was in the right FO/BO activity at the right time. Logged BO duration can explain time allocation, but it cannot supply a missing planned assignment. Before introducing a BO bonus result, obtain case / task ownership, timestamps, due dates, completion, rework and approved assignments. Workflow SLA attainment should include eligible assigned cases due in the period, including unfinished overdue work, with approved exceptions and clear attribution. Complexity-adjusted output is another candidate after validating the case data. No BO numerical target is invented here. BO-only agents need an approved separate configuration; no automatic PCS zero or ad hoc reweighting.

## Recommended starting configuration

Common proposed weights: quality 30%, FO PCS 25%, FO AHT 20%, shift timing compliance 15%, final absence 10%. This replaces the earlier proposed activity-adherence label because the necessary activity plan does not exist. Pure BO applicability must be settled before activation.

Tenured: QM 90%/85%, PCS 4.3/4.1, AHT B/1.10B, shift timing 95%/90%, absence 3%/5%.
Untenured: QM 90%/80%, PCS 4.3/4.0, AHT 1.25B/1.40B, same shift timing and absence targets.

Full earns full component weight; partial earns 75%; tiers do not stack. Proposed cap 100%. Client minima / quality gates take precedence. Weights and numerical targets are proposals to test, not proven optimums. The supplied bonus file has no shift/BO/sample-count evidence for a complete proposed payout backtest. The <3 / ≥3 completed-month tenure boundary is the user's working assumption; hire dates are absent. Original calculations and payouts are unchanged.

## Sources

- [NiCE Adherence Report](https://help.nice-incontact.com/Content/dashboardwem/adherencewfm.htm): conformance definition and late-start / late-end example.
- [Genesys calculation documentation](https://help.genesys.cloud/articles/how-genesys-cloud-calculates-adherence-and-conformance/): adherence and on-queue conformance, dependent on configuration.
- [WFMHub business rules](https://github.com/44rive/WFMHub-Portable/blob/main/docs/BUSINESS_RULES.md): BO is productive, attendance controls, final absence and interval reconciliation.
- [WFMHub metric catalog](https://github.com/44rive/WFMHub-Portable/blob/main/config/default_metrics.toml): final absence numerator / planned-net denominator; no native paid adherence or conformance score defined.
- [WFMHub data contracts](https://github.com/44rive/WFMHub-Portable/blob/main/docs/DATA_CONTRACTS.md): StartEndTimes, Activities, Agent Status, LILO and call-leg inputs.

External references support measurement distinctions and existing definitions, not the proposed weights, thresholds or adjusted timing formula.

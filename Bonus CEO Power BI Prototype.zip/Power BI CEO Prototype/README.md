# Bonus CEO prototype

This is a two-page Power BI report using a frozen snapshot of the supplied Excel workbook. The report follows the WFMHub design system and the structure of the two PowerPoint slides. Filters remain interactive; the underlying data is fixed. No CSV exporter, source connection, gateway or scheduled refresh has been built.

## Open on Windows

1. Copy this entire folder to Windows, or extract the supplied ZIP. Keep the project folders together.
2. Open `Bonus CEO.pbip` in a current Power BI Desktop. If required, enable Power BI project / enhanced report format features under File > Options > Preview features and restart Desktop.
3. The project has no binary model cache. If data is not loaded when opened, select Home > Refresh once to initialize the embedded snapshot. This reads only data already inside the project; it does not read Excel, CSVs or any external system. Future refreshes replay the identical snapshot.
4. Check both report pages, the dropdown filters and the totals below. Save As a `.pbix` for the presentation.
5. Use the Power BI page tabs to switch between Overview and Reachability. The top text navigation is an identity element; use the page tabs for navigation.

Power BI Desktop is unavailable in the authoring environment. The project JSON has been checked against Microsoft's schemas, but Desktop loading, DAX execution and native visual rendering still require a Windows check. `CEO Dashboard Preview.pdf` and the PNGs are generated layout previews, not screenshots from Power BI. Native charts and tables can render differently in Desktop; they remain editable there.

## Baseline

- Business month: August 2026. The original filename says September, but all identified agent rows and the workbook dashboard use 2026-08.
- Identified agents: 181. Configured agents: 162. ACM FR agents without KPI configuration: 19.
- Estimated payout: 169,500 MAD. Positive estimated payouts: 155. Average positive payout: 1,093.55 MAD.
- Agents requiring review: 181. Eight policy decisions remain unvalidated. One agent has no Team Lead.
- Source controls: 9 OK, 4 REVIEW, 2 INFO. These are frozen, workbook-wide checks; they do not change with agent filters.
- Achievement cap: 130%, pending policy validation. Achievement is the saved final achievement after malus.
- 34 configured agents are at 80%+, 8 at 100%+, and 7 at 0%.

## Reconciliation corrections

The workbook dashboard counts two populated Population/Period rows without an Agent ID. These increase RSA NL from 43 identified agents to 44 and RSA VL from 13 to 14, and the loaded-record control from 181 to 183. This prototype counts only identified agent rows. The original check value is retained in the audit snapshot.

Three saved achievement values are 0.7999999999999999, a floating-point representation of 80%. For display and threshold comparisons only, achievement and earned weights are normalized to ten decimal places. This yields 34 agents at 80%+ and aligns with the slide's achievement bands (26 at 80–99%, 6 at 100–129%, 2 at 130%). The PowerPoint's 31-at-80% card disagrees with those bands. Payouts are copied from saved results and are not recalculated or rounded differently.

Unconfigured agents have blank payout and achievement in the reporting model; they appear in Overview as pending configuration and are excluded from reachability denominators. Missing performance values remain missing. KPI charts use all configured agents as the denominator, including agents who have no actual for that KPI, matching the supplied presentation.

Release checks and policy information apply to the whole frozen workbook, while the four main cards, population table and reachability visuals respond to the synced filters. The overview scope note represents the unfiltered snapshot.

## Files

- `Bonus CEO.pbip` and the `.Report` / `.SemanticModel` folders: editable Power BI project with native visuals and embedded data.
- `CEO Dashboard Preview.pdf`, `01 Overview.png`, `02 Reachability.png`: two-page presentation previews.
- `WFMHub Theme.json`: reusable Power BI theme using canonical WFMHub colors.
- `Audit/Frozen Excel Snapshot.json`: source hash, original control checks and frozen agent/KPI data.
- `Audit/Validation.json`: reconciliation and schema-validation results.

The original workbook and presentation were read without modification. This folder contains employee data and is a local presentation artifact, not a repository contribution.

Microsoft format documentation: https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-report and https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-dataset
